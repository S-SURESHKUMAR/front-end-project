# Spotify-clone
I have built a responsive Spotify clone using only HTML and CSS.
* My project incorporates the Flexbox layout model to create a responsive website.
* This guarantees that users can enjoy a seamless experience across various devices and screen sizes, thanks to its adaptable design.
* After I have learned JavaScript, I plan to further expand the project with additional functionalities. 
